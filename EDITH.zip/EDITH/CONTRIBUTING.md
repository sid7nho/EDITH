# 🤝 Contributing to E.D.I.T.H. HUD 🚀

First off, welcome! Thank you for considering contributing to the **EDITH Tactical Desktop Assistant**.

EDITH started out as an original, local passion project developed by a **14-year-old student developer**. Balancing school, exams, and coding means that community contributions, bug fixes, and feature ideas are hugely appreciated!

---

## 📜 Code of Conduct 🛡️

* **Be Friendly & Respectful**: We're all here to learn, build, and have fun.
* **Support Student Devs**: Constructive criticism is welcome; toxicity is not.
* **Keep It Clean**: Ensure all submitted code is readable, safe, and well-commented.

---

## 🛠️ How Can You Help?

### 1. 🐞 Reporting Bugs

Found a bug, visual glitch, or voice processing error?

* Check the **Issues** tab on GitHub to see if it has already been reported.
* If not, open a **New Issue**.
* Include details:
* **OS**: (Windows / macOS / Linux)
* **Python Version**: (e.g., Python 3.11.2)
* **Steps to Reproduce**: What voice command or action triggered the bug?
* **Error Logs**: Copy and paste any console traceback or log output.



### 2. 💡 Requesting Features

Have an idea for a cool new Spider-Man quip, voice shortcut, or PyQt6 visualizer widget?

* Open an **Issue** with the tag `enhancement`.
* Explain clearly what the feature should do and why it would be an epic addition to EDITH.

### 3. 🔀 Submitting Pull Requests (PRs)

Ready to write some code? Follow these steps:

1. **Fork the Repository**: Click the `Fork` button at the top right of this page.
2. **Clone Your Fork**:
`git clone [https://github.com/YOUR-USERNAME/EDITH-HUD.git](https://github.com/YOUR-USERNAME/EDITH-HUD.git)`
`cd EDITH-HUD`
3. **Create a Feature Branch**:
`git checkout -b feature/EpicNewCommand`
4. **Make Your Changes**: Keep your code clean and test it thoroughly!
5. **Commit Your Changes**:
`git commit -m "feat: added new voice control command for Spotify"`
6. **Push to GitHub**:
`git push origin feature/EpicNewCommand`
7. **Open a Pull Request**: Go to the main EDITH repository and submit a PR describing your changes.

---

## 📐 Coding Guidelines

* **Cross-Platform First**: Make sure scripts check the operating system (`sys.platform`) before running platform-specific commands (like Win32 API calls).
* **Minimal External Libraries**: Avoid adding heavy dependencies unless absolutely necessary.
* **Keep Security Handshakes**: Ensure any core engine updates maintain the security authentication token check (`EDITH_AUTHORIZED_LAUNCH`).

---

### **Thank you for helping turn EDITH into the ultimate open-source desktop assistant! 🕷️⚡**