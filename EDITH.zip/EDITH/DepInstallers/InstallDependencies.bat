@echo off
title EDITH HUD - Windows Dependency Installer
echo ===================================================
echo   EDITH HUD // Installing Python Dependencies
echo ===================================================
echo.

cd /d "%~dp0.."

py --version >nul 2>&1
if %errorlevel% neq 0 (
    python --version >nul 2>&1
    if %errorlevel% neq 0 (
        echo [ERROR] Python is not installed or not added to PATH!
        echo Please install Python 3.10+ from python.org and check "Add Python to PATH".
        echo.
        pause
        exit /b 1
    )
    set PY_CMD=python
) else (
    set PY_CMD=py
)

echo [INFO] Installing required libraries from requirements.txt...
%PY_CMD% -m pip install --upgrade pip
%PY_CMD% -m pip install -r requirements.txt

echo.
echo ===================================================
echo   Installation Complete! You can now launch EDITH.
echo ===================================================
echo.
pause
exit