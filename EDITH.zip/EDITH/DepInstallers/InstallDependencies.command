#!/bin/bash

echo "==================================================="
echo "  EDITH HUD // macOS Dependency Installer"
echo "==================================================="
echo ""

# Navigate to parent directory containing requirements.txt
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." >/dev/null 2>&1 && pwd )"
cd "$DIR"

if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python 3 was not found on your system."
    echo "Please install Python 3 via https://www.python.org or Homebrew."
    read -p "Press Enter to exit..."
    exit 1
fi

echo "[INFO] Installing required libraries via pip..."
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt

echo ""
echo "==================================================="
echo "  Installation Complete! You can now launch EDITH."
echo "==================================================="
echo ""
read -p "Press Enter to exit..."
exit 0