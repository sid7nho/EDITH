#!/bin/bash

echo "==================================================="
echo "  EDITH HUD // Linux Dependency Installer"
echo "==================================================="
echo ""

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." >/dev/null 2>&1 && pwd )"
cd "$DIR"

if ! command -v python3 &> /dev/null; then
    echo "[ERROR] python3 could not be found."
    echo "Please install python3 using your package manager (e.g., sudo apt install python3 python3-pip)."
    exit 1
fi

echo "[INFO] Installing required libraries..."
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt

echo ""
echo "==================================================="
echo "  Installation Complete! You can now launch EDITH."
echo "==================================================="
echo ""