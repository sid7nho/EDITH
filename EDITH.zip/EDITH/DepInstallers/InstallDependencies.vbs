Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' Get path to root folder (one level up from Dependency Installers)
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)
parentDir = fso.GetParentFolderName(currentDir)

WshShell.CurrentDirectory = parentDir

' Run pip install headlessly using py/python launcher
WshShell.Run "cmd /c py -m pip install -r requirements.txt || python -m pip install -r requirements.txt", 1, True
MsgBox "EDITH dependencies installed successfully!", 64, "EDITH Setup"