____
# LAUNCH EXTENSIONS:

1) **.vbs** OR **.bat** - Microsoft Windows 10/11
2) **.command** - MacOS
3) **.sh** OR **.desktop** - Linux
___
# WHY DOES THIS EXIST?
- Sometimes, the ".pyw" installer in the *main directory* has issues with compatibility, installing, retrieving, or launching.
- For this reason, installers native to **SPECIFIC** operating systems based on their *file extensions* (refer above) have been made by me for a foolproof way to install the required dependencies for "EDITH.py"
