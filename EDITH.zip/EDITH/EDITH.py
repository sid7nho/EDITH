import sys
import os
import json
import time
import queue
import subprocess
import webbrowser
import requests
import random
import string
from datetime import datetime, timedelta
from pathlib import Path
from ctypes import cast, POINTER, windll
math = __import__('math')

# External Libraries
import socket
import pythoncom
import speech_recognition as sr
import psutil
from PIL import ImageGrab
from ctypes import cast, POINTER
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
import comtypes.client
import urllib.parse
import pyautogui
import win32gui
from PyQt6.QtCore import QThread, pyqtSignal, QObject, QTimer, Qt, QElapsedTimer, QRectF, QPointF, QTime
from PyQt6.QtGui import QFont, QColor, QPixmap, QIcon, QPainter, QPen, QBrush, QImage, QTransform
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTextEdit, QLineEdit, QSlider, QProgressBar,
    QMessageBox, QFrame, QGridLayout, QGraphicsDropShadowEffect,
    QStackedWidget, QTimeEdit, QListWidget, QSpinBox, QComboBox,
)

# ==========================================
# LAUNCH SECURITY CHECK
# ==========================================
if os.environ.get("EDITH_AUTHORIZED_LAUNCH") != "ENABLED_BY_LAUNCHER":
    from PyQt6.QtWidgets import QApplication, QMessageBox
    app = QApplication([])
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Icon.Critical)
    msg.setWindowTitle("EDITH // ACCESS DENIED")
    msg.setText("Direct execution blocked!\n\nEDITH must be initialized using LaunchEdith.")
    msg.exec()
    sys.exit(1)

# ==========================================
# SCRIPT-DIR PATH CONFIGURATION
# ==========================================
SCRIPT_DIR = Path(__file__).parent
CONFIG_FILE = SCRIPT_DIR / "ConfigFiles" / ".edith_hud_config_v11.json"
NOTES_FILE = SCRIPT_DIR / "NotesCaptures" / "Notes" / "EDITHNotes.txt"
SYSTEM_LOG_FILE = SCRIPT_DIR / "Logs" / "EDITH_System_Log.txt"
TASKS_FILE = SCRIPT_DIR / "ConfigFiles" / ".edith_tasks.json"
CAPTURES_DIR = SCRIPT_DIR / "NotesCaptures" / "Captures" 

# ==========================================
# 1. NON-CHANGING MONOCHROME THEME CONFIG
# ==========================================
MONOCHROME_COLOR = "#ffffff"

def write_system_log(category: str, message: str):
    try:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(SYSTEM_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{timestamp}] [{category}] {message}\n")
    except Exception:
        pass

# ==========================================
# 2. SYSTEM TOOLS & UTILITY FUNCTIONS
# ==========================================
def open_app(app_name: str, user_name: str) -> str:
    app = app_name.lower().strip()
    try:
        if "whatsapp" in app:
            subprocess.run(["cmd", "/c", "start", "whatsapp:"], check=False)
            return f"Opening WhatsApp comms line, {user_name}."
        elif "chrome" in app or "browser" in app:
            subprocess.run(["cmd", "/c", "start", "chrome"], check=False)
            return f"Deploying Chrome interface across the network for your research, {user_name}."
        elif "spotify" in app:
            subprocess.run(["cmd", "/c", "start", "spotify:"], check=False)
            return f"Initializing audio arrays, {user_name}."
        elif "notepad" in app:
            subprocess.run(["cmd", "/c", "start", "notepad"], check=False)
            return f"Field Notes deployed, {user_name}."
        elif "calculator" in app or "calc" in app:
            subprocess.run(["cmd", "/c", "start", "calc"], check=False)
            return f"Arithmetic matrix online, {user_name}."
        elif "cmd" in app or "command prompt" in app:
            subprocess.run(["cmd", "/c", "start", "cmd"], check=False)
            return f"Command Prompt initialized, {user_name}."
        elif "code" in app or "vscode" in app:
            subprocess.run(["cmd", "/c", "code"], check=False)
            return f"Launching Visual Studio Code for your development work, {user_name}."
        elif "steam" in app:
            subprocess.run(["cmd", "/c", "start", "steam:"], check=False)
            return f"Booting Steam gaming client, {user_name}."
        else:
            result = subprocess.run(f"start {app}", shell=True, capture_output=True, text=True)
            if result.returncode != 0:
                return f"Windows cannot open {app_name}, {user_name}. Target path not found."
            return f"Booting up {app_name} protocol for you, {user_name}."
    except Exception as e:
        return f"Execution error opening {app_name}, {user_name}: {e}"

def play_spotify_song(query: str, user_name: str) -> str:
    clean_query = query.replace("play on spotify", "").replace("play song", "").replace("play", "").replace("spotify", "").strip()
    if clean_query.endswith(" on"):
        clean_query = clean_query[:-3].strip()

    if not clean_query:
        subprocess.run(["cmd", "/c", "start", "spotify:"], check=False)
        return f"Resuming your Spotify audio stream, {user_name}."
        
    subprocess.run(["cmd", "/c", "start", "spotify:"], check=False)
    time.sleep(2)
    pyautogui.hotkey('ctrl', 'l')
    time.sleep(0.5)
    pyautogui.write(clean_query, interval=0.05)
    pyautogui.press('enter')
    time.sleep(1)
    pyautogui.press('enter')
    return f"Queuing up '{clean_query}' on Spotify, {user_name}."

def close_app_process(app_query: str, user_name: str) -> str:
    target = app_query.replace("close", "").replace("kill", "").replace("terminate", "").strip().lower()
    if not target:
        return f"Please specify which application you want to shut down, {user_name}."
    
    if "explorer" in target or "file explorer" in target:
        closed_count = 0
        try:
            pythoncom.CoInitialize()
            shell = comtypes.client.Dispatch("Shell.Application")
            windows = shell.Windows()
            for window in windows:
                if "explorer.exe" in window.FullName.lower():
                    window.Quit()
                    closed_count += 1
            pythoncom.CoUninitialize()
            if closed_count > 0:
                return f"Successfully closed {closed_count} File Explorer window(s), {user_name}."
            else:
                return f"No open File Explorer windows found, {user_name}."
        except Exception as e:
            return f"Failed to close File Explorer windows: {e}"

    closed_count = 0
    try:
        for proc in psutil.process_iter(['name']):
            proc_name = proc.info['name'].lower()
            if target in proc_name or target + ".exe" == proc_name:
                proc.terminate()
                closed_count += 1
        if closed_count > 0:
            return f"Successfully terminated {closed_count} process(es) matching '{target}', {user_name}."
        else:
            return f"No active process found matching '{target}', {user_name}."
    except Exception as e:
        return f"Failed to close application: {e}"

def search_web(query: str, user_name: str) -> str:
    try:
        search_query = query.replace("search the web for", "").replace("search for", "").replace("search", "").strip()
        if not search_query:
            search_query = "EDITH Tactical Network"
        url = f"https://www.google.com/search?q={search_query}"
        webbrowser.open(url, new=2)
        return f"Executing network search for '{search_query}', {user_name}."
    except Exception as e:
        return f"Web search matrix failure: {e}"

def send_specific_whatsapp(phone: str, message: str, user_name: str) -> str:
    try:
        clean_phone = "".join(filter(str.isdigit, phone))
        if len(clean_phone) == 10:
            phone = "+91" + clean_phone
        elif not phone.startswith("+"):
            phone = "+" + phone.replace("plus", "").strip()
            
        encoded_message = urllib.parse.quote(message)
        whatsapp_uri = f"whatsapp://send?phone={phone}&text={encoded_message}"
        whatsapp_running = any("whatsapp" in p.info['name'].lower() for p in psutil.process_iter(['name']))
        
        if not whatsapp_running:
            subprocess.run(["cmd", "/c", "start", "whatsapp:"], check=False)
            time.sleep(5.5)
        
        webbrowser.open(whatsapp_uri)
        time.sleep(2.5)
        pyautogui.press('enter')
        time.sleep(1.5)
        subprocess.run(["powershell", "-Command", "Stop-Process -Name WhatsApp -Force -ErrorAction SilentlyContinue"], capture_output=True)
        subprocess.run(["powershell", "-Command", "Stop-Process -Name WhatsAppDesktop -Force -ErrorAction SilentlyContinue"], capture_output=True)
        return f"Encrypted transmission dispatched to {phone}, {user_name}."
    except Exception as e:
        return f"Transmission sequence failure, {user_name}: {e}"

def open_folder(folder_query: str, user_name: str) -> str:
    try:
        user_path = Path.home()
        target = folder_query.lower()
        if "downloads" in target:
            path = user_path / "Downloads"
        elif "documents" in target:
            path = user_path / "Documents"
        elif "pictures" in target or "photos" in target:
            path = user_path / "Pictures"
        elif "desktop" in target:
            path = user_path / "Desktop"
        elif "script" in target or "edith" in target:
            path = SCRIPT_DIR
        else:
            path = user_path
            
        if path.exists():
            os.startfile(str(path))
            return f"Opening your {folder_query} directory, {user_name}."
        return f"Requested directory not found in local storage, {user_name}."
    except Exception as e:
        return f"Directory access error: {e}"

def take_screenshot(user_name: str) -> str:
    try:
        CAPTURES_DIR.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        file_path = CAPTURES_DIR / f"EDITH_{timestamp}.png"
        img = ImageGrab.grab()
        img.save(file_path)
        return f"Snapshot captured and secured, {user_name}."
    except Exception as e:
        return f"Screenshot capture failed, {user_name}: {e}"

def check_unread_whatsapp_messages() -> bool:
    unread_found = False
    def enum_windows_callback(hwnd, extra):
        nonlocal unread_found
        if win32gui.IsWindowVisible(hwnd):
            title = win32gui.GetWindowText(hwnd)
            if "whatsapp" in title.lower():
                if "(" in title and ")" in title:
                    unread_found = True
    try:
        win32gui.EnumWindows(enum_windows_callback, None)
    except Exception:
        pass
    return unread_found

def save_script_note(note_text: str, user_name: str) -> str:
    try:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"[{timestamp}] [FIELD NOTE] {note_text}\n"
        with open(NOTES_FILE, "a", encoding="utf-8") as f:
            f.write(entry)
        return f"Field note successfully logged to EDITHNotes.txt, {user_name}."
    except Exception as e:
        return f"Failed to save note, {user_name}: {e}"

def set_master_volume(level_percent: int, user_name: str) -> str:
    try:
        pythoncom.CoInitialize()
        devices = AudioUtilities.GetSpeakers()
        interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        volume = cast(interface, POINTER(IAudioEndpointVolume))
        scalar = max(0.0, min(1.0, level_percent / 100.0))
        volume.SetMasterVolumeLevelScalar(scalar, None)
        pythoncom.CoUninitialize()
        return f"Master audio volume adjusted to {level_percent}%, {user_name}."
    except Exception as e:
        return f"Volume adjustment failed, {user_name}: {e}"

def fetch_bengaluru_weather(user_name: str) -> str:
    try:
        res = requests.get("https://wttr.in/Bengaluru?format=j1", timeout=3)
        if res.status_code == 200:
            data = res.json()
            current = data['current_condition'][0]
            temp = current['temp_C']
            desc = current['weatherDesc'][0]['value']
            return f"Atmospheric telemetry: {temp}°C, {desc}, {user_name}."
        else:
            return f"Atmospheric sensors offline, {user_name}. Weather feed unavailable."
    except Exception:
        return f"Unable to connect to meteorological satellites, {user_name}."

def open_dev_bookmark(target: str, user_name: str) -> str:
    urls = {
        "github": "https://github.com",
        "stackoverflow": "https://stackoverflow.com",
        "youtube": "https://youtube.com",
        "mods": "https://www.nexusmods.com",
        "google": "https://google.com"
    }
    key = target.lower().strip()
    if key in urls:
        webbrowser.open(urls[key])
        return f"Opening {key.capitalize()} portal for you, {user_name}."
    return f"Bookmark '{target}' not found in tactical database, {user_name}."

def clean_system_temp(user_name: str) -> str:
    try:
        temp_dir = Path(os.environ.get('TEMP', 'C:\\Windows\\Temp'))
        deleted = 0
        for item in temp_dir.glob('*'):
            try:
                if item.is_file():
                    item.unlink()
                    deleted += 1
            except Exception:
                pass
        return f"System temp cache purged successfully. {deleted} temporary files cleared, {user_name}."
    except Exception as e:
        return f"Cache purge incomplete, {user_name}: {e}"

def get_network_telemetry(user_name: str) -> str:
    try:
        hostname = socket.gethostname() if 'socket' in globals() else "Localhost"
        ip_addr = requests.get("https://api.ipify.org", timeout=3).text
        return f"Network telemetry online. Public IP: {ip_addr}. Connection secure, {user_name}."
    except Exception:
        return f"Network telemetry check completed. Local connection active, {user_name}."

def get_spiderman_quip(user_name: str) -> str:
    quips = [
        f"With great power comes great electricity bill awareness, {user_name}.",
        f"Web-shooters are loaded and  you cleaner than your suit after patrol, {user_name}.",
        f"Friendly neighborhood reminder: take a breather and hydrate, {user_name}.",
        f"Even Tony Stark needed coffee breaks, {user_name}. You're doing great."
        f"Remember, every hero needs a sidekick. Don't forget to delegate tasks, {user_name}.",
        f"Your Spidey senses are tingling! Time to check your notifications, {user_name}.",
        f"Always remember to stay focused while swinging through the city of code, {user_name}.",
        f"Keep your web fluid clean and your code cleaner, {user_name}.",
        f"It looks like the goblin's on the loose tonight. Stay vigilant, {user_name}.",
        f"Even you need to recharge, Spidey. Take a moment to rest, {user_name}.",
        f"That's a cute outfit. Did your husband give it to you?"
        f"You know, if you're gonna steal a car, don't dress like a car thief, man."
        f"The Avengers? Is that like a band? Were you in a band?"
        f"You know, if you were a real superhero, you'd have a cool name. Like, 'The Amazing Spider-Man.'"
        f"Hey, I know you. You're the guy who was in that movie with the guy who was in that other movie."
        f"Do you ever get tired of swinging around the city? I mean, it must be exhausting."
        f"Spider-Man, Spider-Man, does whatever a spider can. Spins a web, any size, catches thieves just like flies. Look out! Here comes the Spider-Man!"
    ]
    return random.choice(quips)

def generate_secure_password(user_name: str) -> str:
    chars = string.ascii_letters + string.digits + "!@#$%"
    pwd = "".join(random.choice(chars) for _ in range(12))
    save_script_note(f"Generated secure password: {pwd}", user_name)
    return f"Secure 12-character password generated and logged to EDITHNotes.txt, {user_name}."

def run_system_diagnostics(user_name: str) -> str:
    cpu = psutil.cpu_percent()
    ram = psutil.virtual_memory().percent
    disk = psutil.disk_usage(str(SCRIPT_DIR)).percent
    return f"Diagnostics: CPU {cpu}%, RAM {ram}%, Script Drive Usage {disk}%. All systems nominal, {user_name}."

def lock_workstation(user_name: str) -> str:
    try:
        ctypes_dll = windll.user32
        ctypes_dll.LockWorkStation()
        return f"Workstation locked securely, {user_name}."
    except Exception as e:
        return f"Failed to lock workstation: {e}"

# ==========================================
# 3. THREAD 1: NATIVE WINDOWS TTS ENGINE
# ==========================================
class TTSWorker(QThread):
    def __init__(self, listener_ref=None):
        super().__init__()
        self.q = queue.Queue()
        self.is_running = True
        self.listener_ref = listener_ref

    def run(self):
        pythoncom.CoInitialize()
        speaker = None
        try:
            speaker = comtypes.client.CreateObject("SAPI.SpVoice")
        except Exception:
            pythoncom.CoUninitialize()
            return

        while self.is_running:
            try:
                item = self.q.get(timeout=0.1)
                if isinstance(item, tuple):
                    text, post_action_callback = item
                else:
                    text, post_action_callback = item, None

                if text == "<STOP>":
                    try:
                        speaker.Speak("", 2)
                    except Exception:
                        pass
                    continue
                
                if text and text.strip():
                    if self.listener_ref:
                        self.listener_ref.is_speaking = True
                    speaker.Speak(text, 0)
                    if self.listener_ref:
                        time.sleep(0.3)
                        self.listener_ref.is_speaking = False

                if post_action_callback:
                    try:
                        post_action_callback()
                    except Exception:
                        pass
            except queue.Empty:
                pass
            except Exception:
                pass
        pythoncom.CoUninitialize()

    def speak(self, text, callback=None):
        if text and text.strip():
            self.q.put((text, callback))
            
    def stop(self):
        with self.q.mutex:
            self.q.queue.clear()
        self.q.put(("<STOP>", None))
        if self.listener_ref:
            self.listener_ref.is_speaking = False

# ==========================================
# 4. THREAD 2: LISTENER WORKER
# ==========================================
class ListenerWorker(QThread):
    log_signal = pyqtSignal(str, str)
    state_signal = pyqtSignal(str)
    command_signal = pyqtSignal(str)
    
    def __init__(self, user_name="Sid"):
        super().__init__()
        self.is_listening = True
        self.is_running = True
        self.is_speaking = False
        self.user_name = user_name
        
    def run(self):
        recognizer = sr.Recognizer()
        recognizer.pause_threshold = 0.5
        recognizer.energy_threshold = 300
        recognizer.dynamic_energy_threshold = True

        time.sleep(0.5)
        self.log_signal.emit("SYSTEM", f"EDITH-HUD Holographic Command Center Online for {self.user_name}.")
        
        while self.is_running:
            if not self.is_listening or self.is_speaking:
                self.state_signal.emit("muted")
                time.sleep(0.2)
                continue
                
            try:
                with sr.Microphone() as source:
                    if self.is_speaking:
                        continue
                    self.state_signal.emit("idle")
                    recognizer.adjust_for_ambient_noise(source, duration=0.1)
                    
                    self.state_signal.emit("listening")
                    audio = recognizer.listen(source, timeout=None, phrase_time_limit=20)
                    
                    if self.is_speaking:
                        continue
                    
                    self.state_signal.emit("processing")
                    command = recognizer.recognize_google(audio).lower()
                    self.log_signal.emit(self.user_name.upper(), command)
                    self.command_signal.emit(command)
            except sr.UnknownValueError:
                pass
            except Exception:
                time.sleep(0.1)

# ==========================================
# 5. REFINED SCI-FI HOLOGRAPHIC VISUALIZER
# ==========================================
class ReferenceHolographicVisualizer(QWidget):
    def __init__(self, size_scale=160, primary_hex=MONOCHROME_COLOR):
        super().__init__()
        self.setFixedSize(size_scale, size_scale)
        self.primary_hex = primary_hex
        
        self.elapsed_timer = QElapsedTimer()
        self.elapsed_timer.start()
        
        self.theme_color = QColor(self.primary_hex)
        self.theme_color.setAlpha(220)
        
        self.shadow = QGraphicsDropShadowEffect(self)
        self.shadow.setBlurRadius(14)
        self.shadow.setColor(QColor(255, 255, 255, 140))
        self.shadow.setOffset(0, 0)
        self.setGraphicsEffect(self.shadow)
        
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update)
        self.timer.start(16)

    def set_theme_color(self, hex_color):
        pass

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        cx, cy = self.width() / 2.0, self.height() / 2.0
        scale_factor = self.width() / 160.0
        
        painter.save()
        painter.translate(cx, cy)
        painter.scale(scale_factor, scale_factor)
        
        elapsed_ms = self.elapsed_timer.elapsed()
        angle_outer = (elapsed_ms * 0.025) % 360.0
        angle_middle = (elapsed_ms * -0.04) % 360.0
        angle_sweep = (elapsed_ms * 0.12) % 360.0

        # Layer 1: Outer Ring & Degree Ticks
        painter.save()
        painter.rotate(angle_outer)
        pen_outer = QPen(self.theme_color, 1.0, Qt.PenStyle.SolidLine)
        pen_outer.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen_outer)
        
        painter.drawArc(QRectF(-72, -72, 144, 144), 15 * 16, 60 * 16)
        painter.drawArc(QRectF(-72, -72, 144, 144), 105 * 16, 50 * 16)
        painter.drawArc(QRectF(-72, -72, 144, 144), 195 * 16, 70 * 16)
        painter.drawArc(QRectF(-72, -72, 144, 144), 285 * 16, 60 * 16)
        
        for i in range(12):
            painter.rotate(30)
            painter.drawLine(0, -72, 0, -66)
        painter.restore()

        # Layer 2: Counter-Rotating Dashed Telemetry Ring
        painter.save()
        painter.rotate(angle_middle)
        pen_mid = QPen(self.theme_color, 1.0, Qt.PenStyle.DashLine)
        painter.setPen(pen_mid)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawEllipse(QPointF(0, 0), 52, 52)
        
        for i in range(4):
            painter.rotate(90)
            painter.drawLine(0, -52, 0, -46)
        painter.restore()

        # Layer 3: Crosshair Grid
        painter.save()
        pen_cross = QPen(QColor(255, 255, 255, 80), 0.8, Qt.PenStyle.DotLine)
        painter.setPen(pen_cross)
        painter.drawLine(QPointF(-38, 0), QPointF(38, 0))
        painter.drawLine(QPointF(0, -38), QPointF(0, 38))
        painter.restore()

        # Layer 4: Fluid Radar Beam
        painter.save()
        painter.rotate(angle_sweep)
        pen_sweep = QPen(self.theme_color, 1.2, Qt.PenStyle.SolidLine)
        painter.setPen(pen_sweep)
        painter.drawLine(QPointF(0, 0), QPointF(0, -42))
        
        painter.setBrush(QBrush(self.theme_color))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(QPointF(0, -42), 2.5, 2.5)
        painter.restore()

        # Layer 5: Core Control Unit
        painter.save()
        pen_core = QPen(self.theme_color, 1.2, Qt.PenStyle.SolidLine)
        painter.setPen(pen_core)
        painter.setBrush(QBrush(QColor(0, 0, 0, 245)))
        painter.drawEllipse(QPointF(0, 0), 14, 14)
        
        pulse_alpha = int(180 + 75 * math.sin(elapsed_ms / 180.0))
        led_color = QColor(self.theme_color)
        led_color.setAlpha(pulse_alpha)
        painter.setBrush(QBrush(led_color))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(QPointF(0, 0), 4.5, 4.5)
        painter.restore()
        
        painter.restore()

# ==========================================
# 6. STREAMLINED HUD & TASK MANAGER ENGINE
# ==========================================
class FridayCommandCenter(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        self.is_minimized_mode = False
        self.old_pos = None
        
        self.waiting_for = None
        self.temp_phone = ""
        
        self.is_sleep_mode = False
        self.sleep_time = None
        self.sleep_logs = []
        
        self.current_opacity = 240
        self.user_name = "Sid"
        self.setup_completed = False
        
        self.tasks = []
        self.reminders = []
        self.pomodoro_seconds_left = 25 * 60
        self.pomodoro_running = False
        self.is_break_phase = False
        self.current_loop = 1

        # Periodic Quips State
        self.periodic_quips_enabled = False
        self.quip_interval_minutes = 2

        self.load_config()
        self.load_tasks_and_reminders()
        
        self.init_ui()
        if self.setup_completed:
            self.init_systems()
        self.snap_to_desktop_position("normal")

    def snap_to_desktop_position(self, mode="normal"):
        screen = QApplication.primaryScreen().geometry()
        screen_w = screen.width()
        screen_h = screen.height()
        
        if mode == "minimized":
            w, h = 400, 56
            x = (screen_w - w) // 2
            y = 16
        else:
            w = 720
            h = 440
            x = (screen_w - w) // 2
            y = 30
            
        self.setGeometry(x, y, w, h)

    def load_config(self):
        try:
            if CONFIG_FILE.exists():
                with open(CONFIG_FILE, "r") as f:
                    data = json.load(f)
                    self.current_opacity = data.get("opacity", 240)
                    self.user_name = data.get("user_name", "Sid")
                    self.setup_completed = data.get("setup_completed", False)
        except Exception:
            pass

    def save_config(self):
        try:
            data = {
                "opacity": self.current_opacity,
                "user_name": self.user_name,
                "setup_completed": self.setup_completed
            }
            with open(CONFIG_FILE, "w") as f:
                json.dump(data, f)
        except Exception:
            pass

    def load_tasks_and_reminders(self):
        try:
            if TASKS_FILE.exists():
                with open(TASKS_FILE, "r") as f:
                    data = json.load(f)
                    self.tasks = data.get("tasks", [])
                    self.reminders = data.get("reminders", [])
        except Exception:
            self.tasks = []
            self.reminders = []

    def save_tasks_and_reminders(self):
        try:
            data = {"tasks": self.tasks, "reminders": self.reminders}
            with open(TASKS_FILE, "w") as f:
                json.dump(data, f)
        except Exception:
            pass

    def init_ui(self):
        self.bg_frame = QFrame(self)
        self.apply_theme_stylesheet()
        self.setCentralWidget(self.bg_frame)
        
        self.main_layout = QVBoxLayout(self.bg_frame)
        self.main_layout.setContentsMargins(6, 6, 6, 6)  # Tight outer margin so boxes stay close to border
        self.main_layout.setSpacing(8)
        
        # Top Header Bar
        top_bar = QHBoxLayout()
        top_bar.setContentsMargins(8, 2, 8, 2)
        
        status_dot = QLabel("🛡️")
        status_dot.setStyleSheet(f"color: {MONOCHROME_COLOR}; font-size: 13px; border: none; background: transparent;")
        
        self.title_label = QLabel("EDITH-HUD // SETUP" if not self.setup_completed else "EDITH-HUD // CONSOLE")
        self.title_label.setFont(QFont("Consolas", 10, QFont.Weight.Bold))
        self.title_label.setStyleSheet(f"color: {MONOCHROME_COLOR}; letter-spacing: 1px; border: none; background: transparent;")

        self.view_switch_btn = QPushButton("📋 Task Manager")
        self.view_switch_btn.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
        self.view_switch_btn.setStyleSheet(self.get_btn_style())
        self.view_switch_btn.clicked.connect(self.toggle_view)
        if not self.setup_completed:
            self.view_switch_btn.hide()

        self.min_btn = QPushButton("🗕")
        self.min_btn.setFixedSize(24, 24)
        self.min_btn.setFont(QFont("Consolas", 9, QFont.Weight.Bold))
        self.min_btn.setStyleSheet(self.get_btn_style())
        self.min_btn.clicked.connect(self.toggle_minimize_mode)
        
        close_btn = QPushButton("✕")
        close_btn.setFixedSize(24, 24)
        close_btn.setFont(QFont("Consolas", 9, QFont.Weight.Bold))
        close_btn.setStyleSheet(self.get_btn_style("#ffffff"))
        close_btn.clicked.connect(self.close)
        
        top_bar.addWidget(status_dot)
        top_bar.addWidget(self.title_label)
        top_bar.addStretch()
        top_bar.addWidget(self.view_switch_btn)
        top_bar.addWidget(self.min_btn)
        top_bar.addWidget(close_btn)
        self.main_layout.addLayout(top_bar)
        
        # Stacked Central Widget
        self.central_stack = QStackedWidget()
        
        # ==========================================
        # PAGE -1: SETUP SCREEN (ONE-TIME ONLY)
        # ==========================================
        self.setup_container = QWidget()
        setup_layout = QVBoxLayout(self.setup_container)
        setup_layout.setContentsMargins(18, 12, 18, 12)
        setup_layout.setSpacing(12)
        
        setup_header = QLabel("SYSTEM INITIALIZATION & ESSENTIALS")
        setup_header.setFont(QFont("Consolas", 11, QFont.Weight.Bold))
        setup_header.setStyleSheet(f"color: {MONOCHROME_COLOR}; border: none; background: transparent;")
        setup_layout.addWidget(setup_header, 0, Qt.AlignmentFlag.AlignCenter)
        
        setup_desc = QLabel("Welcome, Operator. Configure your primary identity parameters before engaging EDITH-HUD network operations.")
        setup_desc.setFont(QFont("Consolas", 8))
        setup_desc.setStyleSheet("color: #94a3b8; border: none; background: transparent;")
        setup_desc.setWordWrap(True)
        setup_layout.addWidget(setup_desc, 0, Qt.AlignmentFlag.AlignCenter)
        
        form_grid = QGridLayout()
        form_grid.setContentsMargins(10, 10, 10, 10)
        form_grid.setSpacing(10)
        
        name_lbl = QLabel("Your Name / Call Sign:")
        name_lbl.setFont(QFont("Consolas", 9, QFont.Weight.Bold))
        name_lbl.setStyleSheet(f"color: {MONOCHROME_COLOR}; border: none; background: transparent;")
        
        self.setup_name_input = QLineEdit()
        self.setup_name_input.setFont(QFont("Consolas", 9))
        self.setup_name_input.setText(self.user_name)
        self.setup_name_input.setStyleSheet("background: rgba(255, 255, 255, 12); color: white; border: 1px solid rgba(255, 255, 255, 40); border-radius: 5px; padding: 6px;")
        
        form_grid.addWidget(name_lbl, 0, 0)
        form_grid.addWidget(self.setup_name_input, 0, 1)
        setup_layout.addLayout(form_grid)
        
        self.complete_setup_btn = QPushButton("Complete Setup & Initialize HUD")
        self.complete_setup_btn.setFont(QFont("Consolas", 9, QFont.Weight.Bold))
        self.complete_setup_btn.setStyleSheet(self.get_btn_style())
        self.complete_setup_btn.clicked.connect(self.finish_setup_process)
        setup_layout.addWidget(self.complete_setup_btn, 0, Qt.AlignmentFlag.AlignCenter)
        
        self.central_stack.addWidget(self.setup_container)

        # ==========================================
        # PAGE 0: STREAMLINED CONSOLE VIEW
        # ==========================================
        self.mid_container = QWidget()
        mid_layout = QHBoxLayout(self.mid_container)
        mid_layout.setContentsMargins(12, 6, 12, 6)  # Inner padding for text/contents so they don't stick to window edge
        mid_layout.setSpacing(12)
        
        left_column_widget = QWidget()
        left_layout = QVBoxLayout(left_column_widget)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(8)
        
        stats_title = QLabel("SYSTEM METRICS")
        stats_title.setFont(QFont("Consolas", 9, QFont.Weight.Bold))
        stats_title.setStyleSheet(f"color: {MONOCHROME_COLOR}; border: none; background: transparent;")
        left_layout.addWidget(stats_title)
        
        metrics_row = QHBoxLayout()
        metrics_row.setSpacing(12)
        self.cpu_label = QLabel("CPU: --%")
        self.ram_label = QLabel("RAM: --%")
        self.bat_label = QLabel("BAT: --%")
        for lbl in [self.cpu_label, self.ram_label, self.bat_label]:
            lbl.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
            lbl.setStyleSheet("color: #cbd5e1; border: none; background: transparent;")
            metrics_row.addWidget(lbl)
        metrics_row.addStretch()
        left_layout.addLayout(metrics_row)
            
        slider_layout = QHBoxLayout()
        slider_label = QLabel("Opacity:")
        slider_label.setFont(QFont("Consolas", 8))
        slider_label.setStyleSheet("color: #94a3b8; border: none; background: transparent;")
        
        self.opacity_slider = QSlider(Qt.Orientation.Horizontal)
        self.opacity_slider.setRange(120, 255)
        self.opacity_slider.setValue(self.current_opacity)
        self.opacity_slider.setStyleSheet("border: none; background: transparent;")
        self.opacity_slider.valueChanged.connect(self.change_opacity)
        
        slider_layout.addWidget(slider_label)
        slider_layout.addWidget(self.opacity_slider)
        left_layout.addLayout(slider_layout)

        # Periodic Quips Control Layout
        quips_layout = QHBoxLayout()
        quips_label = QLabel("Periodic Quips:")
        quips_label.setFont(QFont("Consolas", 8))
        quips_label.setStyleSheet("color: #94a3b8; border: none; background: transparent;")
        
        self.quip_toggle_btn = QPushButton("OFF")
        self.quip_toggle_btn.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
        self.quip_toggle_btn.setStyleSheet(self.get_btn_style())
        self.quip_toggle_btn.clicked.connect(self.toggle_periodic_quips_ui)
        
        self.quip_interval_combo = QComboBox()
        self.quip_interval_combo.addItems(["2 min", "5 min", "10 min"])
        self.quip_interval_combo.setFont(QFont("Consolas", 8))
        self.quip_interval_combo.setStyleSheet("background: rgba(0, 0, 0, 180); color: white; border: 1px solid rgba(255, 255, 255, 40); border-radius: 4px; padding: 2px;")
        self.quip_interval_combo.currentIndexChanged.connect(self.change_quip_interval)
        
        quips_layout.addWidget(quips_label)
        quips_layout.addWidget(self.quip_toggle_btn)
        quips_layout.addWidget(self.quip_interval_combo)
        left_layout.addLayout(quips_layout)
        
        div = QFrame()
        div.setFrameShape(QFrame.Shape.HLine)
        div.setStyleSheet("background: rgba(255, 255, 255, 30); border: none;")
        left_layout.addWidget(div)

        log_header = QLabel("VOICE LOGS")
        log_header.setFont(QFont("Consolas", 9, QFont.Weight.Bold))
        log_header.setStyleSheet(f"color: {MONOCHROME_COLOR}; border: none; background: transparent;")
        left_layout.addWidget(log_header)

        self.console = QTextEdit()
        self.console.setReadOnly(True)
        self.console.setFont(QFont("Consolas", 9))
        self.console.setStyleSheet("""
            QTextEdit {
                border: 1px solid rgba(255, 255, 255, 40);
                border-radius: 6px;
                background-color: rgba(0, 0, 0, 180);
                color: #e2e8f0;
                padding: 6px;
            }
        """)
        left_layout.addWidget(self.console, 1)

        btn_action_layout = QHBoxLayout()
        btn_action_layout.setSpacing(8)
        self.mute_btn = QPushButton("🎤 Mute")
        self.mute_btn.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
        self.mute_btn.setStyleSheet(self.get_btn_style())
        self.mute_btn.clicked.connect(self.toggle_mute_mic)
        
        self.sleep_btn = QPushButton("🌙 Sleep")
        self.sleep_btn.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
        self.sleep_btn.setStyleSheet(self.get_btn_style())
        self.sleep_btn.clicked.connect(self.toggle_sleep_mode)
        
        btn_action_layout.addWidget(self.mute_btn)
        btn_action_layout.addWidget(self.sleep_btn)
        left_layout.addLayout(btn_action_layout)
        
        mid_layout.addWidget(left_column_widget, 1)
        
        right_column_widget = QWidget()
        right_layout = QVBoxLayout(right_column_widget)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        self.hologram_widget = ReferenceHolographicVisualizer(160, primary_hex=MONOCHROME_COLOR)
        right_layout.addWidget(self.hologram_widget, 0, Qt.AlignmentFlag.AlignCenter)
        mid_layout.addWidget(right_column_widget, 1)
        
        self.central_stack.addWidget(self.mid_container)
        
        # ==========================================
        # PAGE 1: STREAMLINED TASK MANAGER VIEW
        # ==========================================
        self.task_container = QWidget()
        task_layout = QHBoxLayout(self.task_container)
        task_layout.setContentsMargins(12, 6, 12, 6)  # Inner padding for text/contents so they don't stick to window edge
        task_layout.setSpacing(12)
        
        todo_col = QWidget()
        todo_vbox = QVBoxLayout(todo_col)
        todo_vbox.setContentsMargins(0, 0, 0, 0)
        todo_vbox.setSpacing(8)
        
        todo_title = QLabel("TO-DO & REMINDERS")
        todo_title.setFont(QFont("Consolas", 9, QFont.Weight.Bold))
        todo_title.setStyleSheet(f"color: {MONOCHROME_COLOR}; border: none; background: transparent;")
        todo_vbox.addWidget(todo_title)
        
        self.task_input = QLineEdit()
        self.task_input.setFont(QFont("Consolas", 8))
        self.task_input.setPlaceholderText("Enter task or reminder name...")
        self.task_input.setStyleSheet("background: rgba(255, 255, 255, 12); color: white; border: 1px solid rgba(255, 255, 255, 40); border-radius: 5px; padding: 6px;")
        todo_vbox.addWidget(self.task_input)
        
        time_btn_layout = QHBoxLayout()
        time_btn_layout.setSpacing(6)
        self.time_picker = QTimeEdit()
        self.time_picker.setFont(QFont("Consolas", 8))
        self.time_picker.setTime(QTime.currentTime().addSecs(1800))
        self.time_picker.setStyleSheet("background: rgba(0, 0, 0, 180); color: white; border: 1px solid rgba(255, 255, 255, 40); border-radius: 4px; padding: 4px;")
        
        add_task_btn = QPushButton("Add Task")
        add_task_btn.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
        add_task_btn.setStyleSheet(self.get_btn_style())
        add_task_btn.clicked.connect(self.gui_add_task)
        
        add_rem_btn = QPushButton("Reminder")
        add_rem_btn.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
        add_rem_btn.setStyleSheet(self.get_btn_style())
        add_rem_btn.clicked.connect(self.gui_add_reminder)

        time_btn_layout.addWidget(self.time_picker)
        time_btn_layout.addWidget(add_task_btn)
        time_btn_layout.addWidget(add_rem_btn)
        todo_vbox.addLayout(time_btn_layout)
        
        self.task_list_widget = QListWidget()
        self.task_list_widget.setFont(QFont("Consolas", 8))
        self.task_list_widget.setStyleSheet("""
            QListWidget {
                background: rgba(0, 0, 0, 180); 
                color: #e2e8f0; 
                border: 1px solid rgba(255, 255, 255, 40);
                border-radius: 6px;
                padding: 6px;
            }
            QListWidget::item:selected {
                background: rgba(255, 255, 255, 35);
                color: white;
                border-radius: 3px;
            }
        """)
        todo_vbox.addWidget(self.task_list_widget, 1)
        
        remove_btn = QPushButton("Clear Selected Item")
        remove_btn.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
        remove_btn.setStyleSheet(self.get_btn_style())
        remove_btn.clicked.connect(self.gui_remove_selected)
        todo_vbox.addWidget(remove_btn)
        
        task_layout.addWidget(todo_col, 3)
        
        pomo_col = QWidget()
        pomo_vbox = QVBoxLayout(pomo_col)
        pomo_vbox.setContentsMargins(0, 0, 0, 0)
        pomo_vbox.setSpacing(8)
        
        pomo_title = QLabel("POMODORO TIMER")
        pomo_title.setFont(QFont("Consolas", 9, QFont.Weight.Bold))
        pomo_title.setStyleSheet(f"color: {MONOCHROME_COLOR}; border: none; background: transparent;")
        pomo_vbox.addWidget(pomo_title, 0, Qt.AlignmentFlag.AlignCenter)
        
        self.pomo_timer_display = QLabel("25:00")
        self.pomo_timer_display.setFont(QFont("Consolas", 20, QFont.Weight.Bold))
        self.pomo_timer_display.setStyleSheet(f"color: {MONOCHROME_COLOR}; border: none; background: transparent;")
        pomo_vbox.addWidget(self.pomo_timer_display, 0, Qt.AlignmentFlag.AlignCenter)
        
        manual_grid_layout = QHBoxLayout()
        study_vbox = QVBoxLayout()
        study_lbl = QLabel("Study (min)")
        study_lbl.setFont(QFont("Consolas", 7))
        study_lbl.setStyleSheet("color: #94a3b8; border: none; background: transparent;")
        self.study_spin = QSpinBox()
        self.study_spin.setFont(QFont("Consolas", 8))
        self.study_spin.setRange(1, 120)
        self.study_spin.setValue(25)
        self.study_spin.setStyleSheet("background: rgba(0, 0, 0, 180); color: white; border: 1px solid rgba(255, 255, 255, 40); border-radius: 4px;")
        self.study_spin.valueChanged.connect(self.on_manual_pomo_settings_changed)
        study_vbox.addWidget(study_lbl)
        study_vbox.addWidget(self.study_spin)

        break_vbox = QVBoxLayout()
        break_lbl = QLabel("Break (min)")
        break_lbl.setFont(QFont("Consolas", 7))
        break_lbl.setStyleSheet("color: #94a3b8; border: none; background: transparent;")
        self.break_spin = QSpinBox()
        self.break_spin.setFont(QFont("Consolas", 8))
        self.break_spin.setRange(1, 60)
        self.break_spin.setValue(5)
        self.break_spin.setStyleSheet("background: rgba(0, 0, 0, 180); color: white; border: 1px solid rgba(255, 255, 255, 40); border-radius: 4px;")
        self.break_spin.valueChanged.connect(self.on_manual_pomo_settings_changed)
        break_vbox.addWidget(break_lbl)
        break_vbox.addWidget(self.break_spin)

        manual_grid_layout.addLayout(study_vbox)
        manual_grid_layout.addLayout(break_vbox)
        pomo_vbox.addLayout(manual_grid_layout)
        
        pomo_ctrl_layout = QHBoxLayout()
        self.pomo_start_btn = QPushButton("Start")
        self.pomo_start_btn.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
        self.pomo_start_btn.setStyleSheet(self.get_btn_style())
        self.pomo_start_btn.clicked.connect(self.toggle_pomodoro)
        
        pomo_reset_btn = QPushButton("Reset")
        pomo_reset_btn.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
        pomo_reset_btn.setStyleSheet(self.get_btn_style())
        pomo_reset_btn.clicked.connect(self.reset_pomodoro)
        
        pomo_ctrl_layout.addWidget(self.pomo_start_btn)
        pomo_ctrl_layout.addWidget(pomo_reset_btn)
        pomo_vbox.addLayout(pomo_ctrl_layout)

        task_log_header = QLabel("ACTIVITY LOGS")
        task_log_header.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
        task_log_header.setStyleSheet(f"color: {MONOCHROME_COLOR}; border: none; background: transparent;")
        pomo_vbox.addWidget(task_log_header)

        self.task_console = QTextEdit()
        self.task_console.setReadOnly(True)
        self.task_console.setFont(QFont("Consolas", 8))
        self.task_console.setStyleSheet("""
            QTextEdit {
                border: 1px solid rgba(255, 255, 255, 40);
                border-radius: 6px;
                background-color: rgba(0, 0, 0, 180);
                color: #e2e8f0;
                padding: 4px;
            }
        """)
        pomo_vbox.addWidget(self.task_console, 1)
        task_layout.addWidget(pomo_col, 2)
        
        self.central_stack.addWidget(self.task_container)
        self.main_layout.addWidget(self.central_stack)
        
        # Minibar Widget
        self.minibar_container = QWidget()
        minibar_layout = QHBoxLayout(self.minibar_container)
        minibar_layout.setContentsMargins(6, 4, 6, 4)
        minibar_layout.setSpacing(8)
        
        self.mini_hologram = ReferenceHolographicVisualizer(32, primary_hex=MONOCHROME_COLOR)
        
        mini_info_layout = QVBoxLayout()
        mini_info_layout.setContentsMargins(0, 0, 0, 0)
        mini_info_layout.setSpacing(2)
        
        mini_title = QLabel("EDITH-HUD // MINI")
        mini_title.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
        mini_title.setStyleSheet(f"color: {MONOCHROME_COLOR}; border: none; background: transparent;")
        
        self.mini_status_lbl = QLabel("Listening...")
        self.mini_status_lbl.setFont(QFont("Consolas", 7))
        self.mini_status_lbl.setStyleSheet("color: #94a3b8; border: none; background: transparent;")
        
        mini_info_layout.addWidget(mini_title)
        mini_info_layout.addWidget(self.mini_status_lbl)
        
        self.mini_mute_btn = QPushButton("🎤")
        self.mini_mute_btn.setFixedSize(26, 26)
        self.mini_mute_btn.setFont(QFont("Consolas", 9, QFont.Weight.Bold))
        self.mini_mute_btn.setStyleSheet(self.get_btn_style())
        self.mini_mute_btn.clicked.connect(self.toggle_mute_mic)
        
        minibar_layout.addWidget(self.mini_hologram)
        minibar_layout.addLayout(mini_info_layout, 1)
        minibar_layout.addWidget(self.mini_mute_btn)
        
        self.minibar_container.hide()
        self.main_layout.addWidget(self.minibar_container)

        if not self.setup_completed:
            self.central_stack.setCurrentIndex(0) # Setup Screen index
        else:
            self.central_stack.setCurrentIndex(1) # Console View index

        self.metrics_timer = QTimer(self)
        self.metrics_timer.timeout.connect(self.update_system_metrics)
        self.metrics_timer.start(1000)

        self.sleep_monitor_timer = QTimer(self)
        self.sleep_monitor_timer.timeout.connect(self.check_sleep_telemetry)

        self.clock_timer = QTimer(self)
        self.clock_timer.timeout.connect(self.master_clock_tick)
        self.clock_timer.start(1000)

        # Periodic Quip Timer Setup
        self.quip_timer = QTimer(self)
        self.quip_timer.timeout.connect(self.trigger_periodic_quip)

        self.refresh_task_list_widget()

    def finish_setup_process(self):
        name_val = self.setup_name_input.text().strip()
        if name_val:
            self.user_name = name_val
        self.setup_completed = True
        self.save_config()
        
        self.title_label.setText("EDITH-HUD // CONSOLE")
        self.view_switch_btn.show()
        self.central_stack.setCurrentIndex(1)
        
        self.init_systems()
        msg = f"System initialized. Welcome online, {self.user_name}."
        self.log_message("EDITH", msg)
        self.tts.speak(msg)

    # Periodic Quip Management Methods
    def toggle_periodic_quips_ui(self):
        self.periodic_quips_enabled = not self.periodic_quips_enabled
        if self.periodic_quips_enabled:
            self.quip_toggle_btn.setText("ON")
            self.start_quip_timer()
            msg = f"Periodic quips enabled, {self.user_name}."
        else:
            self.quip_toggle_btn.setText("OFF")
            self.quip_timer.stop()
            msg = f"Periodic quips disabled, {self.user_name}."
        self.log_message("EDITH", msg)
        self.tts.speak(msg)

    def start_quip_timer(self):
        idx = self.quip_interval_combo.currentIndex()
        minutes = [2, 5, 10][idx] if 0 <= idx < 3 else 2
        self.quip_interval_minutes = minutes
        self.quip_timer.start(minutes * 60 * 1000)

    def change_quip_interval(self, index):
        minutes = [2, 5, 10][index] if 0 <= index < 3 else 2
        self.quip_interval_minutes = minutes
        if self.periodic_quips_enabled:
            self.start_quip_timer()
        self.log_message("SYSTEM", f"Quip interval set to {minutes} minutes.")

    def trigger_periodic_quip(self):
        if self.periodic_quips_enabled and not self.is_sleep_mode:
            quip = get_spiderman_quip(self.user_name)
            self.log_message("EDITH", quip)
            self.tts.speak(quip)

    def refresh_task_list_widget(self):
        if hasattr(self, 'task_list_widget'):
            self.task_list_widget.clear()
            for task in self.tasks:
                self.task_list_widget.addItem(f"[TASK] {task}")
            for rem in self.reminders:
                self.task_list_widget.addItem(f"[REM] {rem['time']} - {rem['text']}")

    def apply_theme_stylesheet(self):
        self.bg_frame.setStyleSheet(f"""
            QFrame {{
                background-color: rgba(0, 0, 0, {self.current_opacity});
                border: 1px solid rgba(255, 255, 255, 70);
                border-radius: 10px;
            }}
            QScrollBar:vertical {{
                border: none;
                background: rgba(0, 0, 0, 60);
                width: 6px;
                border-radius: 3px;
            }}
            QScrollBar::handle:vertical {{
                background: rgba(255, 255, 255, 120);
                border-radius: 3px;
            }}
        """)

    def get_btn_style(self, custom_color=None):
        col = custom_color if custom_color else MONOCHROME_COLOR
        return f"""
            QPushButton {{ 
                background-color: rgba(255, 255, 255, 12); 
                color: {col}; 
                border-radius: 5px; 
                border: 1px solid rgba(255, 255, 255, 40);
                font-weight: bold;
                padding: 6px;
            }}
            QPushButton:hover {{ background-color: {col}; color: black; }}
        """

    def toggle_view(self):
        if not self.setup_completed:
            return
        current_pos = self.pos()
        if self.central_stack.currentIndex() == 1:
            self.central_stack.setCurrentIndex(2)
            self.view_switch_btn.setText("💻 Console")
            self.title_label.setText("EDITH-HUD // TASKS")
        else:
            self.central_stack.setCurrentIndex(1)
            self.view_switch_btn.setText("📋 Task Manager")
            self.title_label.setText("EDITH-HUD // CONSOLE")
        
        self.setGeometry(current_pos.x(), current_pos.y(), 720, 440)

    def update_system_metrics(self):
        try:
            cpu = psutil.cpu_percent()
            ram = psutil.virtual_memory().percent
            bat = psutil.sensors_battery().percent if psutil.sensors_battery() else 100
            self.cpu_label.setText(f"CPU: {cpu}%")
            self.ram_label.setText(f"RAM: {ram}%")
            self.bat_label.setText(f"BAT: {bat}%")
        except Exception:
            pass

    def change_opacity(self, value):
        self.current_opacity = value
        self.save_config()
        self.apply_theme_stylesheet()

    def toggle_mute_mic(self):
        if hasattr(self, 'listener') and self.listener:
            self.listener.is_listening = not self.listener.is_listening
            if self.listener.is_listening:
                self.mute_btn.setText("🎤 Mute")
                self.mini_mute_btn.setText("🎤")
                self.mini_status_lbl.setText("Listening...")
                self.log_message("SYSTEM", "Microphone active.")
                self.tts.speak(f"Microphone active, {self.user_name}.")
            else:
                self.mute_btn.setText("🔇 Unmute")
                self.mini_mute_btn.setText("🔇")
                self.mini_status_lbl.setText("Muted.")
                self.log_message("SYSTEM", "Microphone muted.")
                self.tts.speak(f"Microphone muted, {self.user_name}.")

    def toggle_sleep_mode(self):
        if not self.is_sleep_mode:
            self.enter_sleep_mode()
        else:
            self.wake_from_sleep_mode()

    def enter_sleep_mode(self):
        self.is_sleep_mode = True
        self.sleep_time = datetime.now()
        self.sleep_logs = []
        self.sleep_btn.setText("☀️ Wake")
        self.log_message("SYSTEM", "Entering Sleep Mode.")
        msg = f"Engaging Sleep Mode, {self.user_name}. Standing by."
        self.log_message("EDITH", msg)
        self.tts.speak(msg)
        if hasattr(self, 'listener') and self.listener:
            self.listener.is_listening = False
        self.sleep_monitor_timer.start(5000)

    def check_sleep_telemetry(self):
        if not self.is_sleep_mode:
            return
        msg_wa = "WhatsApp activity detected."
        if msg_wa not in self.sleep_logs:
            if check_unread_whatsapp_messages():
                self.sleep_logs.append(msg_wa)

        if psutil.sensors_battery():
            bat = psutil.sensors_battery().percent
            msg_bat = f"Low battery: {bat}%."
            if bat < 20 and msg_bat not in self.sleep_logs:
                self.sleep_logs.append(msg_bat)

    def wake_from_sleep_mode(self):
        self.sleep_monitor_timer.stop()
        self.is_sleep_mode = False
        self.sleep_btn.setText("🌙 Sleep")
        briefing = f"Welcome back, {self.user_name}. Systems normal."
        self.log_message("SYSTEM", "Exiting Sleep Mode.")
        self.log_message("EDITH", briefing)
        if hasattr(self, 'listener') and self.listener:
            self.listener.is_listening = True
            self.mute_btn.setText("🎤 Mute")
            self.mini_mute_btn.setText("🎤")
            self.mini_status_lbl.setText("Listening...")
        self.tts.speak(briefing)

    def gui_add_task(self):
        text = self.task_input.text().strip()
        if text:
            self.add_task_item(text)
            self.task_input.clear()

    def add_task_item(self, text):
        self.tasks.append(text)
        self.save_tasks_and_reminders()
        self.refresh_task_list_widget()

    def gui_add_reminder(self):
        text = self.task_input.text().strip()
        time_str = self.time_picker.time().toString("HH:mm")
        if text:
            self.add_reminder_item(text, time_str)
            self.task_input.clear()

    def add_reminder_item(self, text, time_str):
        self.reminders.append({"text": text, "time": time_str})
        self.save_tasks_and_reminders()
        self.refresh_task_list_widget()

    def gui_remove_selected(self):
        row = self.task_list_widget.currentRow()
        if row >= 0:
            item = self.task_list_widget.item(row)
            txt = item.text()
            if txt.startswith("[REM]"):
                target = txt.replace("[REM]", "").strip()
                self.reminders = [r for r in self.reminders if f"{r['time']} - {r['text']}" != target]
            else:
                target = txt.replace("[TASK]", "").strip()
                self.tasks = [t for t in self.tasks if t != target]
            self.save_tasks_and_reminders()
            self.refresh_task_list_widget()

    def on_manual_pomo_settings_changed(self):
        if not self.pomodoro_running and not self.is_break_phase:
            self.pomodoro_seconds_left = self.study_spin.value() * 60
            self.update_pomo_display()

    def update_pomo_display(self):
        m = self.pomodoro_seconds_left // 60
        s = self.pomodoro_seconds_left % 60
        prefix = "[BREAK] " if self.is_break_phase else ""
        self.pomo_timer_display.setText(f"{prefix}{m:02d}:{s:02d}")

    def toggle_pomodoro(self):
        if self.pomodoro_running:
            self.pomodoro_running = False
            self.pomo_start_btn.setText("Start")
        else:
            if self.pomodoro_seconds_left <= 0:
                self.pomodoro_seconds_left = self.study_spin.value() * 60
            self.pomodoro_running = True
            self.pomo_start_btn.setText("Pause")

    def reset_pomodoro(self):
        self.pomodoro_running = False
        self.is_break_phase = False
        self.current_loop = 1
        self.pomo_start_btn.setText("Start")
        self.pomodoro_seconds_left = self.study_spin.value() * 60
        self.update_pomo_display()

    def master_clock_tick(self):
        now_str = datetime.now().strftime("%H:%M")
        triggered = []
        for r in self.reminders:
            if r['time'] == now_str:
                triggered.append(r)
                msg = f"Reminder: {r['text']}"
                self.log_message("EDITH", msg)
                self.tts.speak(msg)

        if triggered:
            self.reminders = [r for r in self.reminders if r not in triggered]
            self.save_tasks_and_reminders()
            self.refresh_task_list_widget()

        if self.pomodoro_running and self.pomodoro_seconds_left > 0:
            self.pomodoro_seconds_left -= 1
            self.update_pomo_display()
            if self.pomodoro_seconds_left == 0:
                if not self.is_break_phase:
                    self.is_break_phase = True
                    self.pomodoro_seconds_left = self.break_spin.value() * 60
                    msg = f"Study block finished. Take a break, {self.user_name}."
                    self.log_message("EDITH", msg)
                    self.tts.speak(msg)
                else:
                    self.is_break_phase = False
                    self.pomodoro_seconds_left = self.study_spin.value() * 60
                    msg = f"Break over. Back to work, {self.user_name}."
                    self.log_message("EDITH", msg)
                    self.tts.speak(msg)

    def toggle_minimize_mode(self):
        if not self.setup_completed:
            return
        if not self.is_minimized_mode:
            self.is_minimized_mode = True
            self.central_stack.hide()
            self.minibar_container.show()
            self.min_btn.setText("🗖")
            self.title_label.setText("EDITH-HUD // MINI")
            self.snap_to_desktop_position("minimized")
        else:
            self.is_minimized_mode = False
            self.minibar_container.hide()
            self.central_stack.show()
            self.min_btn.setText("🗕")
            if self.central_stack.currentIndex() == 1:
                self.title_label.setText("EDITH-HUD // CONSOLE")
            else:
                self.title_label.setText("EDITH-HUD // TASKS")
            self.snap_to_desktop_position("normal")

    def init_systems(self):
        self.listener = ListenerWorker(user_name=self.user_name)
        self.listener.log_signal.connect(self.log_message)
        self.listener.command_signal.connect(self.execute_command)
        
        self.tts = TTSWorker(listener_ref=self.listener)
        self.tts.start()
        self.listener.start()

    def execute_command(self, cmd):
        response_msg = ""
        action_callback = None
        
        if self.waiting_for == "message":
            message_text = cmd
            phone = self.temp_phone
            self.waiting_for = None
            self.temp_phone = ""
            response_msg = f"Dispatching message to {phone}, {self.user_name}."
            action_callback = lambda: send_specific_whatsapp(phone, message_text, self.user_name)
            self.log_message("EDITH", response_msg)
            self.tts.speak(response_msg, callback=action_callback)
            return

        if self.waiting_for == "scratchpad":
            note_text = cmd
            self.waiting_for = None
            response_msg = save_script_note(note_text, self.user_name)
            self.log_message("EDITH", response_msg)
            self.tts.speak(response_msg)
            return

        if "play" in cmd and ("spotify" in cmd or "on spotify" in cmd):
            response_msg = play_spotify_song(cmd, self.user_name)
            self.log_message("EDITH", response_msg)
            self.tts.speak(response_msg)
            return

        if "sleep mode" in cmd or "go to sleep" in cmd:
            self.enter_sleep_mode()
            return

        if self.is_sleep_mode:
            if "wake up" in cmd or "edith" in cmd:
                self.wake_from_sleep_mode()
            return

        # Media Control Handlers (Play/Pause, Skip, Previous)
        if "play" in cmd or "play spotify" in cmd or "play music" in cmd or "play song" in cmd:
                    pyautogui.press('playpause')
                    response_msg = f"Toggling audio playback, {self.user_name}."
        elif "play pause" in cmd or "pause" in cmd or "resume music" in cmd or "stop music" in cmd:
            pyautogui.press('playpause')
            response_msg = f"Toggling audio playback, {self.user_name}."
        elif "skip" in cmd or "next track" in cmd or "next song" in cmd or "next" in cmd:
            pyautogui.press('nexttrack')
            response_msg = f"Skipping to next track, {self.user_name}."
        elif "previous track" in cmd or "prev track" in cmd or "previous song" in cmd or "previous" in cmd:
            pyautogui.press('prevtrack')
            response_msg = f"Returning to previous track, {self.user_name}."
        # Voice Command Handlers for Periodic Quips
        elif "enable quips" in cmd or "turn on quips" in cmd or "start quips" in cmd:
            self.periodic_quips_enabled = True
            self.quip_toggle_btn.setText("ON")
            self.start_quip_timer()
            response_msg = f"Periodic quips activated, {self.user_name}."
        elif "disable quips" in cmd or "turn off quips" in cmd or "stop quips" in cmd:
            self.periodic_quips_enabled = False
            self.quip_toggle_btn.setText("OFF")
            self.quip_timer.stop()
            response_msg = f"Periodic quips deactivated, {self.user_name}."
        elif "quip interval" in cmd or "set quip interval" in cmd:
            if "2" in cmd:
                self.quip_interval_combo.setCurrentIndex(0)
                response_msg = f"Quip interval updated to 2 minutes, {self.user_name}."
            elif "5" in cmd:
                self.quip_interval_combo.setCurrentIndex(1)
                response_msg = f"Quip interval updated to 5 minutes, {self.user_name}."
            elif "10" in cmd:
                self.quip_interval_combo.setCurrentIndex(2)
                response_msg = f"Quip interval updated to 10 minutes, {self.user_name}."
            else:
                response_msg = f"Please specify a valid interval: 2, 5, or 10 minutes, {self.user_name}."
        elif "weather" in cmd or "bengaluru" in cmd:
            response_msg = fetch_bengaluru_weather(self.user_name)
            action_callback = None
        elif "web-slinger" in cmd or "web shooter" in cmd:
            response_msg = f"Web-shooters are fully tensioned and online, {self.user_name}. Ready for patrol."
        elif "stark" in cmd:
            response_msg = f"Tony would be impressed with your code, {self.user_name}."
        elif "quip" in cmd or "joke" in cmd:
            response_msg = get_spiderman_quip(self.user_name)
        elif "diagnostics" in cmd or "system status" in cmd:
            response_msg = run_system_diagnostics(self.user_name)
        elif "password" in cmd:
            response_msg = generate_secure_password(self.user_name)
        elif "clean temp" in cmd or "purge cache" in cmd:
            response_msg = clean_system_temp(self.user_name)
        elif "network" in cmd or "ip address" in cmd:
            response_msg = get_network_telemetry(self.user_name)
        elif "lock workstation" in cmd or "lock computer" in cmd:
            response_msg = lock_workstation(self.user_name)
        elif "bookmark" in cmd or "open github" in cmd or "open stack overflow" in cmd:
            bookmark_target = "github" if "github" in cmd else "stackoverflow" if "stackoverflow" in cmd else "youtube" if "youtube" in cmd else "mods" if "mods" in cmd else "google"
            response_msg = open_dev_bookmark(bookmark_target, self.user_name)
            action_callback = None
        elif "volume" in cmd:
            try:
                digits = "".join(filter(str.isdigit, cmd))
                vol_val = int(digits) if digits else 50
                response_msg = set_master_volume(vol_val, self.user_name)
            except Exception:
                response_msg = set_master_volume(50, self.user_name)
        elif "note" in cmd or "scratchpad" in cmd:
            content = cmd.replace("note", "").replace("scratchpad", "").strip()
            if content:
                response_msg = save_script_note(content, self.user_name)
            else:
                self.waiting_for = "scratchpad"
                response_msg = f"Listening for your note content, {self.user_name}."
        elif "wake up edith" in cmd or "edith" in cmd:
            response_msg = f"EDITH online, {self.user_name}. Standing by."
        elif any(g in cmd for g in ["hello", "hi edith", "hey edith"]):
            response_msg = f"Hello, {self.user_name}."
        elif any(exit_cmd in cmd for exit_cmd in ["shut down hud", "go offline", "quit application", "offline"]):
            response_msg = f"Deactivating EDITH HUD, {self.user_name}."
            action_callback = lambda: QTimer.singleShot(250, self.close)
        elif "screenshot" in cmd or "capture" in cmd:
            response_msg = f"Capturing HUD display, {self.user_name}."
            action_callback = lambda: take_screenshot(self.user_name)
        elif "search" in cmd:
            response_msg = f"Scanning web database, {self.user_name}."
            action_callback = lambda: search_web(cmd, self.user_name)
        elif "open" in cmd:
            app_target = cmd.replace("open", "").strip()
            response_msg = f"Opening {app_target}, {self.user_name}."
            action_callback = lambda: open_app(app_target, self.user_name)
        elif "close" in cmd or "kill" in cmd:
            response_msg = close_app_process(cmd, self.user_name)
            self.log_message("EDITH", response_msg)
            self.tts.speak(response_msg)
            return
        else:
            response_msg = f"Command processed: '{cmd}'."
            
        self.log_message("EDITH", response_msg)
        self.tts.speak(response_msg, callback=action_callback)

    def log_message(self, speaker, text):
        col = MONOCHROME_COLOR if speaker == "EDITH" else "#ffffff" if speaker == self.user_name.upper() or speaker == "SYSTEM" else "#94a3b8"
        formatted_entry = f'<b style="color: {col};">[{speaker}]</b> <span style="color: #e2e8f0;">{text}</span><br>'
        
        if hasattr(self, 'console') and self.console:
            self.console.append(formatted_entry)
            self.console.verticalScrollBar().setValue(self.console.verticalScrollBar().maximum())

        if hasattr(self, 'task_console') and self.task_console:
            self.task_console.append(formatted_entry)
            self.task_console.verticalScrollBar().setValue(self.task_console.verticalScrollBar().maximum())

        self.mini_status_lbl.setText(f"Last [{speaker}]: {text[:24]}...")

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.old_pos = event.globalPosition().toPoint()

    def mouseMoveEvent(self, event):
        if not self.old_pos: 
            return
        delta = event.globalPosition().toPoint() - self.old_pos
        self.move(self.pos() + delta)
        self.old_pos = event.globalPosition().toPoint()

    def mouseReleaseEvent(self, event):
        self.old_pos = None

    def closeEvent(self, event):
        self.save_config()
        self.save_tasks_and_reminders()
        if hasattr(self, 'tts') and self.tts:
            self.tts.is_running = False
            self.tts.stop()
            self.tts.quit()
        if hasattr(self, 'listener') and self.listener:
            self.listener.is_running = False
            self.listener.quit()
        event.accept()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = FridayCommandCenter()
    window.show()
    sys.exit(app.exec())