@echo off
title EDITH HUD Launcher
set EDITH_AUTHORIZED_LAUNCH=ENABLED_BY_LAUNCHER
cd /d "%~dp0.."

:: Launch headlessly using start /b so the batch script exits immediately
start "" /b pyw EDITH.py 2>nul || start "" /b pythonw EDITH.py 2>nul || start "" /b py EDITH.py
exit