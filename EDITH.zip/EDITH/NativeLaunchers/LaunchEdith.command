#!/bin/bash

# Set security token
export EDITH_AUTHORIZED_LAUNCH="ENABLED_BY_LAUNCHER"

# Get parent directory (where EDITH.py lives)
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." >/dev/null 2>&1 && pwd )"
cd "$DIR"

# Launch Python headlessly in the background without keeping Terminal open
nohup python3 EDITH.py >/dev/null 2>&1 &

# Close the Terminal window automatically
kill -9 $PPID