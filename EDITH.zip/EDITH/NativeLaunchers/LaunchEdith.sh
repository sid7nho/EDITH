#!/bin/bash

export EDITH_AUTHORIZED_LAUNCH="ENABLED_BY_LAUNCHER"

# Navigate to parent folder
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." >/dev/null 2>&1 && pwd )"
cd "$DIR"

# Run headlessly in background
nohup python3 EDITH.py >/dev/null 2>&1 &
exit