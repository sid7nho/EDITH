Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' Get parent folder (where EDITH.py lives)
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)
parentDir = fso.GetParentFolderName(currentDir)

' Set authorization environment key
Set env = WshShell.Environment("PROCESS")
env("EDITH_AUTHORIZED_LAUNCH") = "ENABLED_BY_LAUNCHER"

' Set working directory to parent folder
WshShell.CurrentDirectory = parentDir

' Use Python Launcher (pyw) which is built into every standard Windows Python install
WshShell.Run "pyw EDITH.py", 0, False