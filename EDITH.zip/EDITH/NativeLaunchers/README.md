____
# LAUNCH EXTENSIONS:

1) **.vbs** OR **.bat** - Microsoft Windows 10/11
2) **.command** - MacOS
3) **.sh** OR **.desktop** - Linux
___
# WHY DOES THIS EXIST?
- Sometimes, the ".pyw" launcher in the *main directory* has issues with compatibility, or launching.
- For this reason, launchers native to **SPECIFIC** operating systems based on their *file extensions* (refer above) have been made by me for a foolproof way to launch "EDITH.py"
