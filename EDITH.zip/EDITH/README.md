# 🕶️ E.D.I.T.H. HUD — Local Installation Manifest 🚀

> **"Even Dead, I'm The Hero."** — Welcome to the root directory of the **EDITH Tactical Desktop Assistant**! 🕷️⚡

---

## 📖 What Is This Project? 🛠️

This directory houses the **first-ever stable public build** of EDITH-HUD—a remastered, Stark-inspired AI assistant created to run directly on your desktop! 💻

This project started out as a fun local experiment by a **14-year-old student developer**. After endless refining, tweaking, and feature additions, it developed into a full-fledged passion project that was polished enough to release publicly.

While it's designed to be ready for daily tasks, remember: **it is a student-built project and comes with its fair share of bugs!** 🐞 Between school, exams, and life, balancing everything is a continuous work in progress, but EDITH stands ready to serve as your personal desktop companion.

---
## ⚡ Core Features & Capabilities 🎯

* 🎙️ **Hands-Free Voice Interaction**: Operates on live microphone speech input and responds audibly using native Windows SAPI text-to-speech.


* 🎨 **Monochrome Sci-Fi Visualizer**: Powered by PyQt6, featuring a procedural 5-layer rotating holographic radar UI with real-time system metrics (CPU, RAM, Battery).


* 📋 **Task Manager & Pomodoro Timer**: Integrated productivity tools (for suffering children like myself) including a customizable study/break timer, interactive to-do lists, and time-based spoken reminders.


* 🎵 **Media & System Control**: Seamlessly open applications, control Spotify playback, execute web searches, check your area's weather, and adjust master audio levels.


* 🌙 **Intelligent Sleep Mode**: Mutes active listening while silently monitoring background telemetry like low battery levels or unread WhatsApp messages. (THIS IS STILL EXPERIMENTAL, MAY RETURN FALSE POSITIVE WHATSAPP NOTIFICATIONS)


* 🕸️ **Spider-Man Quips Matrix**: Features on-demand or periodic Marvel-inspired quips to keep your workflow engaging.


