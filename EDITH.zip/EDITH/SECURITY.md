# 🛡️ Security & Privacy Policy — E.D.I.T.H. HUD

## 🔒 Commitment to Privacy

The **EDITH Tactical Desktop Assistant** is engineered with a **local-first** approach. Your privacy, desktop environment, and personal data remain entirely under your control.

---

## 🛰️ Data Telemetry & Audio Processing

### 1. 🎙️ Microphone & Voice Data

* **Local Processing Stream**: Audio listened to by EDITH is captured live strictly for real-time intent parsing.
* **No Persistent Audio Storage**: Raw audio files are processed dynamically in memory and are **never recorded, saved to disk, or compiled into audio logs**.
* **Third-Party Processing**: Speech-to-text queries utilize official, standard SpeechRecognition library API bindings to convert spoken phrases into text commands.

### 2. 💻 System Telemetry & Metrics

* **Local Inspection Only**: All system metrics (CPU usage percentage, RAM allocation, battery status, active window process names) are calculated directly on your device via standard system libraries (`psutil`).
* **Zero External Analytics**: System telemetry is never transmitted to outside analytics providers, third-party databases, or remote servers.

### 3. 📝 Local Configuration & Cache Files

* All application files (such as `.edith_hud_config_v11.json`, `.edith_tasks.json`, and local logs) are created and stored **exclusively within your local project directory**.
* No data is synchronized across external servers.

---

## ⚠️ Security Handshake Architecture

EDITH implements a direct runtime authentication handshake (`EDITH_AUTHORIZED_LAUNCH`).

* The core engine (`EDITH.py`) relies on an authorization token passed via environment variables during startup.
* Executing `EDITH.py` directly without running it through the launcher (`LaunchEdith.pyw`,`LaunchEdith.bat`, etc.) will result in an immediate security termination to prevent unauthorized script execution.

---

## 🐛 Reporting Security Vulnerabilities

If you discover a security flaw or vulnerability within EDITH:

1. **Do Not Open a Public Issue**: Please refrain from opening a public GitHub Issue for security vulnerabilities to protect other users.
2. **Contact the Developer**: Submit details directly via a private message or email specified on the lead developer's GitHub profile.
3. **Include Details**: Please describe the nature of the issue, steps to reproduce it, and your operating system details.
---
### **Thank you for keeping EDITH safe and secure for everyone! 🕷️⚡**