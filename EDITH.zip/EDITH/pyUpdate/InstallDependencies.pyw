import sys
import os
import subprocess
import threading
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox

# Locate root directory (one level up from 'Dependency Installers')
SCRIPT_DIR = Path(__file__).parent
ROOT_DIR = SCRIPT_DIR.parent
REQUIREMENTS_FILE = ROOT_DIR / "requirements.txt"

class UniversalInstallerGUI(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("EDITH HUD // Dependency Installer")
        self.geometry("460x260")
        self.resizable(False, False)
        self.configure(bg="#0a0a0a")

        # Center Window on Screen
        self.update_idletasks()
        x = (self.winfo_screenwidth() // 2) - (460 // 2)
        y = (self.winfo_screenheight() // 2) - (260 // 2)
        self.geometry(f"460x260+{x}+{y}")

        self.init_ui()

    def init_ui(self):
        # Header Label
        header_lbl = tk.Label(
            self, 
            text="🛡️ E.D.I.T.H. DEPENDENCY MATRIX", 
            font=("Consolas", 12, "bold"), 
            fg="#ffffff", 
            bg="#0a0a0a"
        )
        header_lbl.pack(pady=(18, 5))

        sub_lbl = tk.Label(
            self, 
            text="Cross-Platform Automated Pip Package Installer", 
            font=("Consolas", 8), 
            fg="#94a3b8", 
            bg="#0a0a0a"
        )
        sub_lbl.pack(pady=(0, 15))

        # Status Label
        self.status_lbl = tk.Label(
            self, 
            text="Ready to initialize installation...", 
            font=("Consolas", 9), 
            fg="#cbd5e1", 
            bg="#0a0a0a",
            wraplength=420
        )
        self.status_lbl.pack(pady=5)

        # Progress Bar
        self.progress = ttk.Progressbar(self, mode="indeterminate", length=380)
        self.progress.pack(pady=15)

        # Install Button
        self.install_btn = tk.Button(
            self, 
            text="INSTALL ALL DEPENDENCIES", 
            font=("Consolas", 9, "bold"), 
            fg="#000000", 
            bg="#ffffff", 
            activebackground="#cbd5e1",
            activeforeground="#000000",
            relief="flat",
            padx=15,
            pady=6,
            cursor="hand2",
            command=self.start_installation_thread
        )
        self.install_btn.pack(pady=(5, 15))

    def start_installation_thread(self):
        if not REQUIREMENTS_FILE.exists():
            messagebox.showerror(
                "File Error", 
                f"requirements.txt not found in root directory!\nPath: {REQUIREMENTS_FILE}"
            )
            return

        self.install_btn.config(state="disabled", bg="#334155", fg="#64748b")
        self.status_lbl.config(text="Upgrading pip & fetching packages...", fg="#ffffff")
        self.progress.start(10)

        # Run subprocess execution in background thread to keep GUI responsive
        threading.Thread(target=self.run_pip_install, daemon=True).start()

    def run_pip_install(self):
        try:
            # Upgrade pip first
            subprocess.run(
                [sys.executable, "-m", "pip", "install", "--upgrade", "pip"],
                cwd=str(ROOT_DIR),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False
            )

            # Install requirements.txt
            process = subprocess.Popen(
                [sys.executable, "-m", "pip", "install", "-r", str(REQUIREMENTS_FILE)],
                cwd=str(ROOT_DIR),
                stdout=subprocess.PIPE,
                stderr=subprocess.STPIPE if hasattr(subprocess, 'STPIPE') else subprocess.PIPE,
                text=True
            )

            stdout, stderr = process.communicate()

            if process.returncode == 0:
                self.after(0, self.on_success)
            else:
                self.after(0, lambda: self.on_failure(stderr if stderr else stdout))

        except Exception as e:
            self.after(0, lambda: self.on_failure(str(e)))

    def on_success(self):
        self.progress.stop()
        self.status_lbl.config(text="SUCCESS: All EDITH dependencies installed!", fg="#4ade80")
        messagebox.showinfo("Installation Complete", "All required Python packages have been successfully installed!\n\nYou can now launch EDITH.")
        self.destroy()

    def on_failure(self, error_msg):
        self.progress.stop()
        self.status_lbl.config(text="ERROR: Installation failed!", fg="#f87171")
        self.install_btn.config(state="normal", bg="#ffffff", fg="#000000")
        messagebox.showerror("Installation Failed", f"An error occurred while installing packages:\n\n{error_msg[:300]}")

if __name__ == "__main__":
    app = UniversalInstallerGUI()
    app.mainloop()