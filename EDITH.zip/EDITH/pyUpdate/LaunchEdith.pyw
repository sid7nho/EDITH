import sys
import os
import subprocess
from pathlib import Path

from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal
from PyQt6.QtGui import QFont, QColor
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QLabel, 
    QPushButton, QFrame, QGraphicsDropShadowEffect, QHBoxLayout
)

SCRIPT_DIR = Path(__file__).parent
EDITH_SCRIPT = (SCRIPT_DIR).parent / "EDITH.py"
AUTH_KEY = "EDITH_AUTHORIZED_LAUNCH"
AUTH_VALUE = "ENABLED_BY_LAUNCHER"

class LaunchWorker(QThread):
    finished_signal = pyqtSignal(bool, str)

    def run(self):
        if not EDITH_SCRIPT.exists():
            self.finished_signal.emit(False, "EDITH.py core binary not found in root directory!")
            return

        try:
            # Pass authorization environment variable
            env = os.environ.copy()
            env[AUTH_KEY] = AUTH_VALUE

            # Platform-specific process execution without console windows
            if sys.platform == "win32":
                # DETACHED_PROCESS = 0x00000008, CREATE_NO_WINDOW = 0x08000000
                creation_flags = 0x08000000 | 0x00000008
                
                # Try finding pythonw.exe first for clean execution on Windows
                pythonw_path = Path(sys.executable).parent / "pythonw.exe"
                executable = str(pythonw_path) if pythonw_path.exists() else sys.executable

                subprocess.Popen(
                    [executable, str(EDITH_SCRIPT)],
                    env=env,
                    cwd=str(SCRIPT_DIR),
                    creationflags=creation_flags,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    stdin=subprocess.DEVNULL,
                    close_fds=True
                )
            else:
                # macOS / Linux headless launch
                subprocess.Popen(
                    [sys.executable, str(EDITH_SCRIPT)],
                    env=env,
                    cwd=str(SCRIPT_DIR),
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    stdin=subprocess.DEVNULL,
                    start_new_session=True
                )

            self.finished_signal.emit(True, "EDITH online.")
        except Exception as e:
            self.finished_signal.emit(False, f"Launch error: {str(e)}")

class LaunchEdithGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(380, 220)
        
        self.old_pos = None
        self.init_ui()
        self.center_on_screen()

    def center_on_screen(self):
        screen = QApplication.primaryScreen().geometry()
        x = (screen.width() - self.width()) // 2
        y = (screen.height() - self.height()) // 2
        self.move(x, y)

    def init_ui(self):
        self.bg_frame = QFrame(self)
        self.bg_frame.setGeometry(0, 0, 380, 220)
        self.bg_frame.setStyleSheet("""
            QFrame {
                background-color: rgba(10, 10, 10, 245);
                border: 1px solid rgba(255, 255, 255, 80);
                border-radius: 12px;
            }
        """)

        # Drop shadow effect
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(20)
        shadow.setColor(QColor(255, 255, 255, 80))
        shadow.setOffset(0, 0)
        self.bg_frame.setGraphicsEffect(shadow)

        layout = QVBoxLayout(self.bg_frame)
        layout.setContentsMargins(16, 12, 16, 16)

        # Header Bar
        header = QHBoxLayout()
        title_lbl = QLabel("🛡️ E.D.I.T.H. // LAUNCHER")
        title_lbl.setFont(QFont("Consolas", 10, QFont.Weight.Bold))
        title_lbl.setStyleSheet("color: #ffffff; border: none; background: transparent;")
        
        close_btn = QPushButton("✕")
        close_btn.setFixedSize(20, 20)
        close_btn.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
        close_btn.setStyleSheet("""
            QPushButton { color: #ffffff; background: rgba(255,255,255,15); border: 1px solid rgba(255,255,255,40); border-radius: 4px; }
            QPushButton:hover { background: #ffffff; color: #000000; }
        """)
        close_btn.clicked.connect(self.close)

        header.addWidget(title_lbl)
        header.addStretch()
        header.addWidget(close_btn)
        layout.addLayout(header)

        layout.addSpacing(10)

        # Status Display
        self.status_lbl = QLabel("SYSTEM STANDBY\nReady for authentication sequence...")
        self.status_lbl.setFont(QFont("Consolas", 8))
        self.status_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.status_lbl.setStyleSheet("color: #cbd5e1; border: none; background: transparent;")
        layout.addWidget(self.status_lbl)

        layout.addSpacing(10)

        # Launch Button
        self.launch_btn = QPushButton("INITIALIZE EDITH")
        self.launch_btn.setFont(QFont("Consolas", 9, QFont.Weight.Bold))
        self.launch_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.launch_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 255, 255, 20);
                color: #ffffff;
                border: 1px solid rgba(255, 255, 255, 80);
                border-radius: 6px;
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #ffffff;
                color: #000000;
            }
            QPushButton:disabled {
                background-color: rgba(255, 255, 255, 5);
                color: #64748b;
                border: 1px solid rgba(255, 255, 255, 20);
            }
        """)
        self.launch_btn.clicked.connect(self.start_launch)
        layout.addWidget(self.launch_btn)

    def start_launch(self):
        self.launch_btn.setEnabled(False)
        self.status_lbl.setText("AUTHENTICATING LAUNCH ENVIRONMENT...\nDispatching secure subprocess...")
        
        self.worker = LaunchWorker()
        self.worker.finished_signal.connect(self.on_launch_complete)
        self.worker.start()

    def on_launch_complete(self, success, message):
        if success:
            self.status_lbl.setText(f"SUCCESS: {message}\nClosing launcher in 1.5 seconds...")
            QTimer.singleShot(1500, self.close)
        else:
            self.status_lbl.setText(f"ERROR: {message}")
            self.launch_btn.setEnabled(True)

    # Window drag support
    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.old_pos = event.globalPosition().toPoint()

    def mouseMoveEvent(self, event):
        if not self.old_pos:
            return
        delta = event.globalPosition().toPoint() - self.old_pos
        self.move(self.pos() + delta)
        self.old_pos = event.globalPosition().toPoint()

    def mouseReleaseEvent(self, event):
        self.old_pos = None

if __name__ == "__main__":
    app = QApplication(sys.argv)
    launcher = LaunchEdithGUI()
    launcher.show()
    sys.exit(app.exec())