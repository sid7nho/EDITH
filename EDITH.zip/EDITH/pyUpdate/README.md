____
# LAUNCH EXTENSIONS:

1) **.pyw** - UNIVERSAL.

___
# WHY DOES THIS EXIST?
- This is a universal section for installing the required dependencies for EDITH, and launching EDITH.
- Universal basically means it works on all operating systems.
- If these do not work, feel free to check out the "DepInstallers" folder for alternative OS-specific native installers for the required dependencies.
